import { NextResponse } from "next/server"

export async function GET() {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "https://spin-to-earn-pi.vercel.app"

  const manifest = {
    accountAssociation: {
      header:
        "eyJmaWQiOjEyMzQ1LCJ0eXBlIjoiY3VzdG9keSIsImtleSI6IjB4MTIzNDU2Nzg5MGFiY2RlZjEyMzQ1Njc4OTBhYmNkZWYxMjM0NTY3OCJ9",
      payload: "eyJkb21haW4iOiJzcGluLXRvLWVhcm4tcGkudmVyY2VsLmFwcCJ9",
      signature: "MHg...",
    },
    frame: {
      version: "1",
      name: "Monad Spin Game",
      iconUrl: `${baseUrl}/icon.png`,
      homeUrl: baseUrl,
      imageUrl: `${baseUrl}/frame-image.png`,
      buttonTitle: "🎰 Play Spin Game",
      splashImageUrl: `${baseUrl}/splash.png`,
      splashBackgroundColor: "#1e3a8a",
      webhookUrl: `${baseUrl}/api/webhook`,
    },
  }

  return NextResponse.json(manifest, {
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "public, max-age=3600",
      "Access-Control-Allow-Origin": "*",
    },
  })
}
