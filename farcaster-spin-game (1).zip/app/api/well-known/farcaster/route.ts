import { NextResponse } from "next/server"

export async function GET() {
  // Redirect to the Farcaster hosted manifest
  return NextResponse.redirect(
    "https://api.farcaster.xyz/miniapps/hosted-manifest/019798d9-fc0e-4f20-175a-eae6f674718e",
    307,
  )
}
